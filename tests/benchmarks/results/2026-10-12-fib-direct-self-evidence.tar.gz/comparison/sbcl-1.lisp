(load (compile-file "/tmp/egcl-fib-parity/comparison-35a2185f/fib_self.lisp" :output-file "/tmp/egcl-fib-parity/comparison-35a2185f/sbcl-1.fasl"))
(dotimes (warm 6000) (fib 8))

(assert (= (fib 35) 9227465))
(format t "FIB-DISASSEMBLY-BEGIN~%")
(disassemble 'fib)
(format t "FIB-DISASSEMBLY-END~%")
(finish-output)

(dotimes (sample 7)
  (let* ((start (get-internal-real-time))
         (checksum (fib 35))
         (elapsed (- (get-internal-real-time) start)))
    (assert (= checksum 9227465))
    (format t "FIB-SAMPLE ~D ~D ~D ~D~%"
            sample elapsed internal-time-units-per-second checksum)
    (finish-output)))
(format t "FIB-DISASSEMBLY-BEGIN~%")
(disassemble 'fib)
(format t "FIB-DISASSEMBLY-END~%")
(finish-output)

