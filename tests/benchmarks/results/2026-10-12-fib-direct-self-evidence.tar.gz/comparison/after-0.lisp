(load "/tmp/egcl-fib-parity/comparison-35a2185f/fib_self.lisp")
(dotimes (warm 6000) (fib 8))

(dotimes (attempt 1000)
  (when (= 2 (egcl-ext:function-tier 'fib)) (return))
  (fib 8)
  (sleep 0.01))
(assert (= 2 (egcl-ext:function-tier 'fib)))

(assert (= (fib 35) 9227465))
(format t "FIB-DISASSEMBLY-BEGIN~%")

(let ((code (egcl::%native-code 'fib)))
  (assert (first code))
  (format t "FIB-CODE-BASE ~D~%" (second code)))
(disassemble 'fib)
(format t "FIB-DISASSEMBLY-END~%")
(finish-output)

(dotimes (sample 7)
  (let* ((start (get-internal-real-time))
         (checksum (fib 35))
         (elapsed (- (get-internal-real-time) start)))
    (assert (= checksum 9227465))
    (format t "FIB-SAMPLE ~D ~D ~D ~D~%"
            sample elapsed internal-time-units-per-second checksum)
    (finish-output)))
(format t "FIB-DISASSEMBLY-BEGIN~%")

(let ((code (egcl::%native-code 'fib)))
  (assert (first code))
  (format t "FIB-CODE-BASE ~D~%" (second code)))
(disassemble 'fib)
(format t "FIB-DISASSEMBLY-END~%")
(finish-output)

