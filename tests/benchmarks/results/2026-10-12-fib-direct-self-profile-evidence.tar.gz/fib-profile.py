import importlib.util, pathlib, os, subprocess, time, select, json
root=pathlib.Path('/tmp/evergreen-fib-calls')
spec=importlib.util.spec_from_file_location('fib_runner',root/'tests/benchmarks/fib_self.py')
runner=importlib.util.module_from_spec(spec); spec.loader.exec_module(runner)
out=pathlib.Path('/tmp/egcl-fib-parity/profile-35a2185f'); out.mkdir(exist_ok=False)
source=root/'tests/benchmarks/fib_self.lisp'
bins={'after':'/tmp/egcl-fib-parity/egcl-after-35a2185f','sbcl':'/home/linuxbrew/.linuxbrew/bin/sbcl'}
manifest={'iterations':10,'cpu':4,'trials':[], 'method':'perf stat user-only cpu_core counters enabled after warmup/prelisting, disabled after ten checked fib35 calls; includes loop/check/printing and brief file handshake overhead'}
def wait_file(path,p):
    deadline=time.monotonic()+90
    while not path.exists():
        if p.poll() is not None: raise RuntimeError(f'process exited {p.returncode} waiting for {path}')
        if time.monotonic()>deadline: raise TimeoutError(str(path))
        time.sleep(.002)
for trial in range(1):
    for side in ('after',):
        name=f'{side}-{trial}'; d=out/name; d.mkdir()
        ready=d/'ready'; go=d/'go'; done=d/'done'; stop=d/'stop'
        ctl=d/'control'; ack=d/'ack'; os.mkfifo(ctl); os.mkfifo(ack)
        cfd=os.open(ctl,os.O_RDWR|os.O_NONBLOCK); afd=os.open(ack,os.O_RDWR|os.O_NONBLOCK)
        def control(command):
            os.write(cfd,(command+'\n').encode())
            if not select.select([afd],[],[],10)[0]: raise TimeoutError('perf acknowledgement')
            reply=os.read(afd,1024)
            if b'ack\n' not in reply: raise RuntimeError(repr(reply))
        def signal(path):
            return f'(with-open-file (s {runner.lisp_string(path)} :direction :output :if-exists :supersede :if-does-not-exist :create) (write-line "ready" s))\n'
        def wait(path):
            return f'(loop until (probe-file {runner.lisp_string(path)}) do (sleep 0.001))\n'
        code=runner.driver(side,source,d/'fib.fasl')
        marker='(dotimes (sample 7)'
        code=code.replace(marker, signal(ready)+wait(go)+'(dotimes (sample 10)',1)
        end=code.rfind('(format t "FIB-DISASSEMBLY-BEGIN')
        code=code[:end]+signal(done)+wait(stop)+code[end:]
        script=d/'driver.lisp'; script.write_text(code)
        binary=bins[side]
        command=['taskset','-c','4','perf','record','-F','999','-o',str(d/'perf.data'),'-D','-1','--control',f'fifo:{ctl},{ack}','-e','cpu_core/cycles/u','--',binary]
        if side=='sbcl': command+=['--noinform','--non-interactive','--no-userinit','--no-sysinit','--load',str(script)]
        else: command+=['--no-init','--load',str(script)]
        command=[str(root/'scripts/egcl-limited.sh')]+command
        env={k:v for k,v in os.environ.items() if not k.startswith(('EGCL_','BLISS_','SBCL_'))}
        env.update(EGCL_FORCE_TIER='t2',EGCL_PERF_MAP='1',EGCL_MEM_MAX='1G',EGCL_TIMEOUT='180')
        record={'side':side,'trial':trial,'command':command};manifest['trials'].append(record)
        with (d/'stdout').open('w') as stdout,(d/'stderr').open('w') as stderr:
            p=subprocess.Popen(command,cwd=root,env=env,stdout=stdout,stderr=stderr)
            try:
                wait_file(ready,p);control('enable');go.touch()
                wait_file(done,p);control('disable');stop.touch()
                rc=p.wait(timeout=30)
                if rc: raise RuntimeError(f'{name}: exit{rc}')
                record.update(runner.parse_trial((d/'stdout').read_text(),side,10))
                record['perf']='perf.data'
                print(name,record['perf'],flush=True)
            finally:
                os.close(cfd);os.close(afd)
                (out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
